### Hexlet tests and linter status:
[![Actions Status](https://github.com/Motlakhov/python-project-83/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Motlakhov/python-project-83/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/f95e5efcb06b832fe962/maintainability)](https://codeclimate.com/github/Motlakhov/python-project-83/maintainability)

Посмотреть результат можно по ссылке: [python-project-83-s8pp.onrender.com](https://python-project-83-s8pp.onrender.com)